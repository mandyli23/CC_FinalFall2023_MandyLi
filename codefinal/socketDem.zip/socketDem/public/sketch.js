
var socket; /// keep track of my socket connection
var messageInput;
var sendButton;
var receivedMessages = [];
var clickedImages = []; 


function setup() {
  createCanvas(2000, 800);
  background(0);

  x = width / 2;
  y = height / 2;

//message sending
  messageInput = createInput();   //input box
  messageInput.position(827, 580);

  sendButton = createButton('Send'); //button
  sendButton.position(messageInput.x + messageInput.width, 580);
  sendButton.mousePressed(sendMessage);
//

  //starting the socket connection to the server
  socket = io.connect('http://localhost:8080');
  // when we get information from the server about the
  //other user/player:
  socket.on('mouse', 
    function(data){
      console.log("Got: "+ data.x, + " " + data.y);
      //fill(0,0, 255);//sends one persons data to other person and fills it as blue
      stroke(100);
      rect(data.x, data.y, 40, 40);
    });


//msg
    socket.on('message',
    function (data) {
      console.log("Received message: " + data.message);
      receivedMessages.push(data.message)
    });

//index of imgs
  socket.on('idx',
    function (data) {
      console.log("Got idx: " + data.idx);
      
      // Push the clicked image into the array
     // rect(data.x, data.y, 40, 40);

      clickedImages.push({ x: data.x, y: data.y }); //{} creates object
    });

} //

var img1;
var img2;
var img3;

var img4;
var img5;
var img6;

var img7;
var img8;
var img9;

function preload(){

img1 = loadImage('icons/carousel.png');
img2 = loadImage('icons/clapperboard.png');
img3 = loadImage('icons/clown.png');

img4 = loadImage('icons/confetti.png');
img5 = loadImage('icons/popcorn.png');
img6 = loadImage('icons/money.png');

img7 = loadImage('icons/paint.png');
img8 = loadImage('icons/pinwheel.png');
img9 = loadImage('icons/teddybear.png');


}

let l1 = 50; //loc variable
let l2 = l1 + 250;
let l3 = l2 + 250;
let l4 = l3 + 250;
let l5 = l4 + 250;


let s2 = 150; //size variable(for all icons)

function draw() {
 background(255);

stroke(255, 0, 0);
strokeWeight(4);
rectMode(CENTER);
rect(mouseX, mouseY, 200, 200);

//images row 1
image(img1, l1, l1, s2, s2); //carousel
image(img2, l2, l1, s2, s2); //clapperboard
image(img3, l3, l1, s2, s2); //clown

//images row 2
image(img4, l1, l2, s2, s2); //confetti
image(img5, l2, l2, s2, s2); //popcorn
image(img6, l3, l2, s2, s2)  //money

//images row 3
image(img7, l1, l3, s2, s2); //paint
image(img8, l2, l3, s2, s2); //pinwheel
image(img9, l3, l3, s2, s2); //teddybear

//textbox
stroke(0);
fill(255);
rect(1080, 300, 500, 500);

textSize(16);
text('Player one: Select an object & give hints', 1080, 120, 300, 100);
text('Player two: Guess and click the correct object. You may ask for hints!', 1080, 145, 300, 100)

 fill(255);
  textSize(16);
  textAlign(LEFT);
  var msgTxt = receivedMessages.join("\n");  //shows messages in the text box
  text(msgTxt, 1080 + 10, 320 +10, 500-20, 400-20);  //(size of original box paddin--> width and height)

//attempt at recieving clicked images

    for (let i = 0; i < clickedImages.length; i++) {
    let { x, y } = clickedImages[i];
    stroke(0, 255, 0);
    strokeWeight(4);
    noFill();
    rect(x, y, 40, 40); //xy are extracted values

  
  }


}



function mousePressed() {   //sending images to the other person but it doesn't show

//images 1-3
  if (wasClicked(l1, l1, s2, s2)) {
    send_imgindex(1, mouseX, mouseY);
    } //else if (wasClicked(l1, l1, s2, s2) && )

  if (wasClicked(l2, l1, s2, s2)) {
    send_imgindex(2);
  }

  if (wasClicked(l3, l1, s2, s2)) {
    send_imgindex(3);
  }

//images 3-6
  if (wasClicked(l1, l2, s2, s2)) {
    send_imgindex(4);
  }

  if (wasClicked(l2, l2, s2, s2)) {
    send_imgindex(5);
  }

  if (wasClicked(l3, l2, s2, s2)) {
    send_imgindex(6);
  }

//images 6-9
  if (wasClicked(l1, l3, s2, s2)) {
    send_imgindex(7);
  }

  if (wasClicked(l2, l3, s2, s2)) {
    send_imgindex(8);
  }

  if (wasClicked(l3, l3, s2, s2)) {
    send_imgindex(9);
  }
   
}
//  var msgTxt = receivedImgs
//   text(msgTxt, 1080 + 10, 300 +10, 500-20, 500-20);

// }



function wasClicked(x, y, w, h) {
  if (
    mouseX > x &&
    mouseX < x + w &&
    mouseY > y &&
    mouseY < y + h
  ) {
    return true;
  } else {
    return false;
  }
}



function sendMessage() {
  // Send the text message to the server
  var message = messageInput.value();
  var data = {
    message: message
  };
  socket.emit('message', data);
}

function send_imgindex(idx, mouseX, mouseY){
  //we are sending:

  var data = {
    idx: idx,
    x: mouseX, // Store the x position
    y: mouseY, // Store the y position

  }

  //send that object to the socket
  socket.emit('idx', data);

  //clickedImages.push({ x: mouseX, y: mouseY });
 
  console.log("sent img: " + idx);

}

//if the function and if statement are true, emit
